#include <stdio.h>

int main() {
    printf("hello, world!\n");
    printf("동해물과 백두산이\n 마르고\n 닳도록\n");
    printf("동해물과 백두산이");
    printf("마르고");
    printf("닳도록");
}

